# -*- coding: utf-8 -*-
import bijoy as B
H=B.H
def build():
    t={}  # glyph -> (type, unicode)
    for u,g in B.BASE.items(): t[g]=('C',u)
    for u,g in B.OTHER.items():
        if u in '০১২৩৪৫৬৭৮৯': t[g]=('O',u)
        else: t[g]=('O',u)
    t['|']=('O','।')
    for u,g in B.LIG.items(): t[g]=('C',u)
    for u,g in B.KAR_POST.items(): t[g]=('P',u)
    t['\u0160']=('P','ৌ#')   # Š : second half of ৌ
    for u,g in B.KAR_PRE.items(): t[g]=('R',u)
    t['\u00a9']=('F','')     # ref
    t['\u00a8']=('Y','')
    t['\u00d6']=('A','');t['\u00aa']=('A','')
    t['&']=('H','')
    return t
T=build(); MAXL=max(len(g) for g in T)
def convert(s):
    units=[];i=0
    while i<len(s):
        for L in range(min(MAXL,len(s)-i),0,-1):
            g=s[i:i+L]
            if g in T: units.append((T[g][0],T[g][1],g)); i+=L; break
        else: units.append(('X',s[i],s[i])); i+=1
    out=[]; cl=None  # cl: dict(pre,text,ref,post)
    pend=''
    def flush():
        nonlocal cl
        if cl is None: return
        k=cl['pre']; post=cl['post']
        kars=''
        if 'ে' in k and 'া' in post: kars+='ো'; post=post.replace('া','',1); k=k.replace('ে','',1)
        elif 'ে' in k and 'ৌ#' in post: kars+='ৌ'; post=post.replace('ৌ#','',1); k=k.replace('ে','',1)
        kars+=k+post
        out.append(('র'+H if cl['ref'] else '')+cl['text']+kars); cl=None
    join=False
    for typ,u,g in units:
        if typ=='R': flush(); pend+=u; continue
        if typ=='C':
            if join and cl is not None: cl['text']+=H+u; join=False
            else:
                flush(); cl={'pre':pend,'text':u,'ref':False,'post':''}; pend=''
            continue
        if typ=='Y' and cl: cl['text']+=('\u200d' if cl['text'].endswith('র') else '')+H+'য'; continue
        if typ=='A' and cl: cl['text']+=H+'র'; continue
        if typ=='F' and cl: cl['ref']=True; continue
        if typ=='P' and cl: cl['post']+=u; continue
        if typ=='H' and cl: join=True; continue
        flush()
        if pend: out.append(pend); pend=''
        join=False
        out.append(u if typ in 'OX' else u)
    flush(); 
    if pend: out.append(pend)
    return ''.join(out)
if __name__=='__main__':
    words=['বাংলা','আমি','শিক্ষা','সুন্দর','ধর্ম','প্রথম','উত্তর','শান্তি','বিজ্ঞান','সম্পর্ক','ব্যবহার','কোথায়','দৈনিক','ইচ্ছা','যুক্ত','সৃষ্টি','সূর্য','বাংলাদেশ','কর্মী','র‍্যাব','কৌশল','কক্ক ঘ্র ১২৩ ।','বর্তমানে','সর্বোচ্চ','মূল্য','ঢাকা শহরে অনেক মানুষ থাকেন।']
    bad=0
    for w in words:
        b=B.convert(w); r=convert(b)
        ref=B.norm(w)
        ok=r==ref; bad+=not ok
        print('OK ' if ok else 'BAD',w,repr(b),r)
    print('bad',bad)
