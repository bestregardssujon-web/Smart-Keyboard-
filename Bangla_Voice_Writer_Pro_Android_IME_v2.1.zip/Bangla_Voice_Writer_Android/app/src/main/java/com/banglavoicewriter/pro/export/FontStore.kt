package com.banglavoicewriter.pro.export

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import java.io.File

/**
 * Keeps a user-supplied SutonnyMJ (or any Bijoy ANSI) font file.
 * The font is NOT bundled with the app: SutonnyMJ is a commercial font, so the
 * user imports their own licensed copy. It is used for PDF export and preview.
 */
class FontStore(private val context: Context) {
    private val file: File get() = File(File(context.filesDir, "fonts"), "SutonnyMJ.ttf")

    fun load(): Typeface? {
        val f = file
        if (!f.exists() || !looksLikeFont(f)) return null
        return try {
            Typeface.createFromFile(f)
        } catch (e: Exception) {
            null
        }
    }

    /** Copies the chosen file into app storage. Returns an error message or null on success. */
    fun importFrom(uri: Uri): String? {
        return try {
            val dir = File(context.filesDir, "fonts")
            if (!dir.exists()) dir.mkdirs()
            val tmp = File(dir, "import.tmp")
            val input = context.contentResolver.openInputStream(uri) ?: return "Could not open the file."
            input.use { ins -> tmp.outputStream().use { out -> ins.copyTo(out) } }
            if (!looksLikeFont(tmp)) {
                tmp.delete()
                return "That file is not a TrueType/OpenType font (.ttf / .otf)."
            }
            val target = file
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) return "Could not save the font."
            null
        } catch (e: Exception) {
            "Could not import font: ${e.message}"
        }
    }

    fun remove() {
        file.delete()
    }

    companion object {
        /** TrueType (00 01 00 00 / 'true') or OpenType-CFF ('OTTO') header check. */
        fun looksLikeFont(f: File): Boolean {
            if (f.length() < 12) return false
            val h = ByteArray(4)
            f.inputStream().use { if (it.read(h) < 4) return false }
            val tag = String(h, Charsets.ISO_8859_1)
            return (h[0].toInt() == 0 && h[1].toInt() == 1 && h[2].toInt() == 0 && h[3].toInt() == 0) ||
                tag == "true" || tag == "OTTO"
        }
    }
}
