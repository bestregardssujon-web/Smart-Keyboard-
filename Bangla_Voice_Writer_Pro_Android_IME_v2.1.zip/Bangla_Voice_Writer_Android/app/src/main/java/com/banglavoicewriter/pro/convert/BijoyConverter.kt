package com.banglavoicewriter.pro.convert

import com.banglavoicewriter.pro.convert.BijoyTables.HASANTA
import com.banglavoicewriter.pro.convert.BijoyTables.HASANTA_GLYPH
import com.banglavoicewriter.pro.convert.BijoyTables.REPH
import com.banglavoicewriter.pro.convert.BijoyTables.YA_PHALA
import com.banglavoicewriter.pro.convert.BijoyTables.ZWJ
import com.banglavoicewriter.pro.convert.BijoyTables.ZWNJ

/** Script of a converted run: Bangla runs need the Bijoy font, Latin runs must NOT use it. */
enum class Script { BANGLA, LATIN }

data class Segment(val text: String, val script: Script)

/**
 * Unicode Bangla -> Bijoy Classic / SutonnyMJ ANSI.
 *
 * Handles: consonants, independent vowels, kar (with pre-base reordering of
 * i-kar, e-kar, oi-kar and the split o-kar / ou-kar), reph, ya-phala, ra-phala,
 * conjunct ligatures from [BijoyTables.ligatures], explicit hasanta, digits,
 * danda, and smart quotes. Latin text is passed through unchanged (and reported
 * as [Script.LATIN] by [convertSegments] so exporters can keep it out of the
 * Bijoy font, where it would otherwise display as Bangla glyphs).
 */
object BijoyConverter {
    private const val BN = 0
    private const val LAT = 1
    private const val NEU = 2

    private class Piece(val text: String, val kind: Int)

    private val consonantMap: Map<Char, String> = BijoyTables.consonants.mapKeys { it.key[0] }
    private val otherMap: Map<Char, String> = BijoyTables.others.mapKeys { it.key[0] }
    private val postKarMap: Map<Char, String> = BijoyTables.postKars.mapKeys { it.key[0] }
    private val preKarMap: Map<Char, String> = BijoyTables.preKars.mapKeys { it.key[0] }
    private val neutralMap: Map<Char, String> = BijoyTables.neutralBangla.mapKeys { it.key[0] }
    private const val O_KAR = '\u09CB'
    private const val OU_KAR = '\u09CC'
    private const val RA = '\u09B0'
    private const val YA = '\u09AF'

    private fun isConsonant(c: Char) = consonantMap.containsKey(c)
    private fun isKar(c: Char) =
        preKarMap.containsKey(c) || postKarMap.containsKey(c) || c == O_KAR || c == OU_KAR
    private fun isJoiner(c: Char) = c == ZWNJ || c == ZWJ

    /** Canonical form: precomposed ড় ঢ় য়, and o-kar / ou-kar as single characters. */
    fun normalize(input: String): String = input
        .replace("\u09A1\u09BC", "\u09DC")
        .replace("\u09A2\u09BC", "\u09DD")
        .replace("\u09AF\u09BC", "\u09DF")
        .replace("\u09C7\u09BE", "\u09CB")
        .replace("\u09C7\u09D7", "\u09CC")

    /** Plain converted string (all scripts concatenated). */
    fun toBijoy(unicode: String): String =
        convertSegments(unicode).joinToString("") { it.text }

    fun convertSegments(unicode: String): List<Segment> {
        val s = normalize(unicode)
        val n = s.length
        val pieces = ArrayList<Piece>()
        var i = 0
        while (i < n) {
            val c = s[i]
            if (isConsonant(c) || isKar(c)) {
                var ref = false
                var body = ""
                if (isConsonant(c)) {
                    if (c == RA && i + 2 < n && s[i + 1] == HASANTA && isConsonant(s[i + 2])) {
                        ref = true
                        i += 2
                    }
                    val cons = ArrayList<String>()
                    cons.add(s[i].toString())
                    i++
                    while (true) {
                        var j = i
                        while (j < n && isJoiner(s[j])) j++
                        if (j + 1 < n && s[j] == HASANTA && isConsonant(s[j + 1])) {
                            cons.add(s[j + 1].toString())
                            i = j + 2
                        } else {
                            break
                        }
                    }
                    body = clusterGlyphs(cons)
                    if (i < n && s[i] == HASANTA) {
                        body += HASANTA_GLYPH
                        i++
                        while (i < n && isJoiner(s[i])) i++
                    }
                }
                val pre = StringBuilder()
                val post = StringBuilder()
                while (i < n && isKar(s[i])) {
                    val k = s[i]
                    when {
                        preKarMap.containsKey(k) -> pre.append(preKarMap[k])
                        k == O_KAR -> {
                            pre.append(preKarMap['\u09C7'])
                            post.append(postKarMap['\u09BE'])
                        }
                        k == OU_KAR -> {
                            pre.append(preKarMap['\u09C7'])
                            post.append("\u0160")
                        }
                        else -> post.append(postKarMap[k])
                    }
                    i++
                }
                pieces.add(Piece(pre.toString() + body + (if (ref) REPH else "") + post, BN))
            } else if (otherMap.containsKey(c)) {
                pieces.add(Piece(otherMap[c]!!, BN))
                i++
            } else if (isJoiner(c)) {
                i++
            } else if (c.code in 0x0980..0x09FF) {
                pieces.add(Piece(c.toString(), BN)) // unmapped Bangla character: keep as is
                i++
            } else if (c.isWhitespace() || (c.code < 128 && !c.isLetterOrDigit()) || neutralMap.containsKey(c)) {
                pieces.add(Piece(c.toString(), NEU))
                i++
            } else {
                pieces.add(Piece(c.toString(), LAT))
                i++
            }
        }
        return resolve(pieces)
    }

    /** Neutral characters (spaces, punctuation) join the surrounding run. */
    private fun resolve(pieces: List<Piece>): List<Segment> {
        var cur = pieces.firstOrNull { it.kind != NEU }?.kind ?: LAT
        val out = ArrayList<Segment>()
        val sb = StringBuilder()
        var sbKind = cur
        for (p in pieces) {
            val kind: Int
            var text = p.text
            if (p.kind == NEU) {
                kind = cur
                if (kind == BN && p.text.length == 1) {
                    text = neutralMap[p.text[0]] ?: p.text
                }
            } else {
                cur = p.kind
                kind = p.kind
            }
            if (kind != sbKind && sb.isNotEmpty()) {
                out.add(Segment(sb.toString(), if (sbKind == BN) Script.BANGLA else Script.LATIN))
                sb.setLength(0)
            }
            sbKind = kind
            sb.append(text)
        }
        if (sb.isNotEmpty()) {
            out.add(Segment(sb.toString(), if (sbKind == BN) Script.BANGLA else Script.LATIN))
        }
        return out
    }

    private fun clusterGlyphs(cons: List<String>): String {
        val res = StringBuilder()
        val n = cons.size
        var i = 0
        val joiner = HASANTA.toString()
        while (i < n) {
            var matched = false
            var len = minOf(4, n - i)
            while (len >= 2) {
                val key = cons.subList(i, i + len).joinToString(joiner)
                val lig = BijoyTables.ligatures[key]
                if (lig != null) {
                    res.append(lig)
                    i += len
                    matched = true
                    break
                }
                len--
            }
            if (matched) continue
            val c = cons[i]
            if (i == 0) {
                res.append(BijoyTables.consonants[c])
            } else if (c[0] == YA) {
                res.append(YA_PHALA)
            } else if (c[0] == RA) {
                res.append(BijoyTables.raPhala[cons[i - 1]] ?: BijoyTables.RA_PHALA_FALLBACK)
            } else {
                res.append(HASANTA_GLYPH).append(BijoyTables.consonants[c])
            }
            i++
        }
        return res.toString()
    }
}
