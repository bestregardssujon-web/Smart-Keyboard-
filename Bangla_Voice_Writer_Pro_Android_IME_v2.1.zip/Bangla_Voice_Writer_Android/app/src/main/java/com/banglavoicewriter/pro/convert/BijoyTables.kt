package com.banglavoicewriter.pro.convert

/**
 * Unicode <-> Bijoy Classic (SutonnyMJ) ANSI glyph tables.
 *
 * Written from the publicly documented Bijoy keyboard/glyph layout (own table,
 * no third-party converter code). Entries are limited to glyphs that are well
 * documented; any conjunct NOT listed in [ligatures] is emitted with an explicit
 * hasanta glyph (readable, but not a fused ligature). See README for limits.
 *
 * NOTE: the glyph characters live in the Latin-1 / Windows-1252 range. They are
 * written as unicode escapes so file encoding can never corrupt them.
 */
internal object BijoyTables {
    const val HASANTA = '\u09CD'
    const val ZWNJ = '\u200C'
    const val ZWJ = '\u200D'
    const val NUKTA = '\u09BC'

    /** Glyph used for an explicit (visible) hasanta. */
    const val HASANTA_GLYPH = "&"
    /** Ya-phala glyph. */
    const val YA_PHALA = "\u00A8"
    /** Reph (r + hasanta before a consonant) glyph, placed after the cluster. */
    const val REPH = "\u00A9"
    /** Ra-phala glyph used when the base letter has no entry in [raPhala]. */
    const val RA_PHALA_FALLBACK = "&i"

    /** Consonants (full form). */
    val consonants: Map<String, String> = mapOf(
        "\u0995" to "K",  // ক
        "\u0996" to "L",  // খ
        "\u0997" to "M",  // গ
        "\u0998" to "N",  // ঘ
        "\u0999" to "O",  // ঙ
        "\u099A" to "P",  // চ
        "\u099B" to "Q",  // ছ
        "\u099C" to "R",  // জ
        "\u099D" to "S",  // ঝ
        "\u099E" to "T",  // ঞ
        "\u099F" to "U",  // ট
        "\u09A0" to "V",  // ঠ
        "\u09A1" to "W",  // ড
        "\u09A2" to "X",  // ঢ
        "\u09A3" to "Y",  // ণ
        "\u09A4" to "Z",  // ত
        "\u09A5" to "_",  // থ
        "\u09A6" to "`",  // দ
        "\u09A7" to "a",  // ধ
        "\u09A8" to "b",  // ন
        "\u09AA" to "c",  // প
        "\u09AB" to "d",  // ফ
        "\u09AC" to "e",  // ব
        "\u09AD" to "f",  // ভ
        "\u09AE" to "g",  // ম
        "\u09AF" to "h",  // য
        "\u09B0" to "i",  // র
        "\u09B2" to "j",  // ল
        "\u09B6" to "k",  // শ
        "\u09B7" to "l",  // ষ
        "\u09B8" to "m",  // স
        "\u09B9" to "n",  // হ
        "\u09DC" to "o",  // ড়
        "\u09DD" to "p",  // ঢ়
        "\u09DF" to "q"  // য়
    )
    /** Independent vowels, digits, danda and other single characters. */
    val others: Map<String, String> = mapOf(
        "\u09CE" to "r",  // ৎ
        "\u0982" to "s",  // ং
        "\u0983" to "t",  // ঃ
        "\u0981" to "u",  // ঁ
        "\u0985" to "A",  // অ
        "\u0986" to "Av",  // আ
        "\u0987" to "B",  // ই
        "\u0988" to "C",  // ঈ
        "\u0989" to "D",  // উ
        "\u098A" to "E",  // ঊ
        "\u098B" to "F",  // ঋ
        "\u098F" to "G",  // এ
        "\u0990" to "H",  // ঐ
        "\u0993" to "I",  // ও
        "\u0994" to "J",  // ঔ
        "\u09E6" to "0",  // ০
        "\u09E7" to "1",  // ১
        "\u09E8" to "2",  // ২
        "\u09E9" to "3",  // ৩
        "\u09EA" to "4",  // ৪
        "\u09EB" to "5",  // ৫
        "\u09EC" to "6",  // ৬
        "\u09ED" to "7",  // ৭
        "\u09EE" to "8",  // ৮
        "\u09EF" to "9",  // ৯
        "\u0964" to "|"  // ।
    )
    /** Vowel signs written AFTER the consonant cluster. */
    val postKars: Map<String, String> = mapOf(
        "\u09BE" to "v",  // া
        "\u09C0" to "x",  // ী
        "\u09C1" to "y",  // ু
        "\u09C2" to "~",  // ূ
        "\u09C3" to "\u201E"  // ৃ
    )
    /** Vowel signs written BEFORE the consonant cluster (visual order). */
    val preKars: Map<String, String> = mapOf(
        "\u09BF" to "w",  // ি
        "\u09C7" to "\u2021",  // ে
        "\u09C8" to "\u02DC"  // ৈ
    )
    /** Conjunct (hasanta-joined) sequences with a dedicated glyph sequence. */
    val ligatures: Map<String, String> = mapOf(
        "\u0995\u09CD\u09B7" to "\u00B6",  // ক্ষ
        "\u0995\u09CD\u09A4" to "\u00B3",  // ক্ত
        "\u0995\u09CD\u09B0" to "\u00B5",  // ক্র
        "\u09A4\u09CD\u09B0" to "\u00CE",  // ত্র
        "\u09A4\u09CD\u09A4" to "\u00CB",  // ত্ত
        "\u09A8\u09CD\u09A4" to "\u0161\u00CD",  // ন্ত
        "\u09A8\u09CD\u09A6" to "\u203A`",  // ন্দ
        "\u09AE\u09CD\u09AA" to "\u00A4\u00FA",  // ম্প
        "\u09AE\u09CD\u09AE" to "\u00A4\u00A7",  // ম্ম
        "\u09AE\u09CD\u09AC" to "\u00A4^",  // ম্ব
        "\u09B8\u09CD\u09AC" to "\u00AF^",  // স্ব
        "\u09B8\u09CD\u0995" to "\u00AF\u2039",  // স্ক
        "\u09B8\u09CD\u09A5" to "\u00AF\u2019",  // স্থ
        "\u09B8\u09CD\u09A4" to "\u00AFZ",  // স্ত
        "\u099A\u09CD\u099A" to "\u201DP",  // চ্চ
        "\u099A\u09CD\u099B" to "\u201DQ",  // চ্ছ
        "\u099C\u09CD\u099C" to "\u00BE",  // জ্জ
        "\u099C\u09CD\u099E" to "\u00C1",  // জ্ঞ
        "\u0999\u09CD\u0997" to "\u00BD",  // ঙ্গ
        "\u0999\u09CD\u0995" to "\u00BC",  // ঙ্ক
        "\u0997\u09CD\u09A8" to "M\u0153",  // গ্ন
        "\u09B7\u09CD\u099F" to "\u00F3",  // ষ্ট
        "\u09B7\u09CD\u09A0" to "\u00F4",  // ষ্ঠ
        "\u09AA\u09CD\u09A4" to "\u00DF",  // প্ত
        "\u09A6\u09CD\u09A7" to "\u00D7",  // দ্ধ
        "\u09A6\u09CD\u09AC" to "`\u00A6"  // দ্ব
    )
    /** Ra-phala glyph by base consonant. */
    val raPhala: Map<String, String> = mapOf(
        "\u09AA" to "\u00D6",  // প
        "\u0997" to "\u00D6",  // গ
        "\u09B6" to "\u00D6",  // শ
        "\u09AC" to "\u00AA",  // ব
        "\u09AD" to "\u00AA",  // ভ
        "\u09A1" to "\u00AA",  // ড
        "\u099F" to "\u00AA",  // ট
        "\u09A6" to "\u00AA",  // দ
        "\u09B8" to "\u00AA"  // স
    )
    /** Smart quotes, converted only when inside Bangla text. */
    val neutralBangla: Map<String, String> = mapOf(
        "\u2018" to "\u00D4",  // ‘
        "\u2019" to "\u00D5",  // ’
        "\u201C" to "\u00D2",  // “
        "\u201D" to "\u00D3"  // ”
    )
}
