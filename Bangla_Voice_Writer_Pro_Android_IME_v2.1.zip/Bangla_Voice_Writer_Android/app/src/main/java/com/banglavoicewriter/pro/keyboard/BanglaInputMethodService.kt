package com.banglavoicewriter.pro.keyboard

import android.inputmethodservice.InputMethodService
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.banglavoicewriter.pro.convert.AvroPhonetic
import com.banglavoicewriter.pro.convert.BijoyConverter

/**
 * First IME implementation for Bangla Voice Writer Pro.
 *
 * Modes:
 * EN: direct English QWERTY.
 * বাংলা: Avro-style phonetic input producing Unicode Bangla.
 * ANSI: Avro-style phonetic input, converted to the project's Bijoy ANSI
 *       representation when a word is committed. This is not the original
 *       Bijoy Classic physical key layout.
 */
class BanglaInputMethodService : InputMethodService() {

    private enum class Mode { ENGLISH, BANGLA, ANSI }
    private var mode = Mode.ENGLISH
    private var composing = StringBuilder()
    private var keyboardRoot: LinearLayout? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var listening = false

    override fun onCreateInputView(): View {
        return buildKeyboard().also { keyboardRoot = it }
    }

    override fun onStartInput(attribute: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        composing.clear()
        updateModeButtons()
    }

    override fun onFinishInput() {
        stopSpeech()
        composing.clear()
        super.onFinishInput()
    }

    override fun onDestroy() {
        stopSpeech()
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        super.onDestroy()
    }

    private fun buildKeyboard(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(Color.rgb(225, 230, 238))
        }
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(makeButton("EN") { setMode(Mode.ENGLISH) }, weighted())
        modes.addView(makeButton("বাংলা") { setMode(Mode.BANGLA) }, weighted())
        modes.addView(makeButton("ANSI") { setMode(Mode.ANSI) }, weighted())
        modes.addView(makeButton(if (listening) "■" else "🎤") { toggleSpeech() }, weighted())
        root.addView(modes, rowParams())

        addKeyRow(root, listOf("q","w","e","r","t","y","u","i","o","p"))
        addKeyRow(root, listOf("a","s","d","f","g","h","j","k","l"))
        addKeyRow(root, listOf("⇧","z","x","c","v","b","n","m","⌫"))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(makeButton("?123") { commitSpecial("?123") }, weighted(1f))
        bottom.addView(makeButton(",") { typeCharacter(",") }, weighted(.7f))
        bottom.addView(makeButton("English / বাংলা") { setMode(if (mode == Mode.ENGLISH) Mode.BANGLA else Mode.ENGLISH) }, weighted(2.2f))
        bottom.addView(makeButton(".") { typeCharacter(".") }, weighted(.7f))
        bottom.addView(makeButton("↵") { pressEnter() }, weighted(1f))
        root.addView(bottom, rowParams())
        val hint = TextView(this).apply {
            text = when (mode) {
                Mode.ENGLISH -> "English keyboard"
                Mode.BANGLA -> "Avro phonetic: ami → আমি"
                Mode.ANSI -> "ANSI output: use with SutonnyMJ font"
            }
            textSize = 11f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        root.addView(hint)
        return root
    }

    private fun addKeyRow(root: LinearLayout, keys: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        keys.forEach { key ->
            row.addView(makeButton(key) {
                when (key) {
                    "⌫" -> backspace()
                    "⇧" -> Toast.makeText(this, "Shift is not included in this first build.", Toast.LENGTH_SHORT).show()
                    else -> typeCharacter(key)
                }
            }, weighted())
        }
        root.addView(row, rowParams())
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.rgb(25, 35, 50))
            setBackgroundColor(Color.WHITE)
            typeface = Typeface.DEFAULT
            setPadding(dp(1), dp(1), dp(1), dp(1))
            setOnClickListener { action() }
        }

    private fun weighted(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, dp(46), weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }

    private fun rowParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setMode(next: Mode) {
        if (mode == next) return
        commitPending()
        mode = next
        refreshKeyboard()
    }

    private fun updateModeButtons() {
        // Mode state is reflected in the rebuilt keyboard.
    }

    private fun refreshKeyboard() {
        keyboardRoot = buildKeyboard()
        setInputView(keyboardRoot)
    }

    private fun typeCharacter(key: String) {
        val ic = currentInputConnection ?: return
        if (key == " " || key == "." || key == "," || key == "?" || key == "!") {
            commitPending()
            ic.commitText(key, 1)
            return
        }
        if (mode == Mode.ENGLISH) {
            ic.commitText(key, 1)
        } else {
            composing.append(key)
            val preview = AvroPhonetic.transliterate(composing.toString())
            ic.setComposingText(preview, 1)
        }
    }

    private fun commitPending() {
        if (composing.isEmpty()) return
        val ic = currentInputConnection
        if (ic != null) {
            val unicode = AvroPhonetic.transliterate(composing.toString())
            val output = if (mode == Mode.ANSI) BijoyConverter.toBijoy(unicode) else unicode
            ic.commitText(output, 1)
        }
        composing.clear()
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length - 1)
            if (composing.isEmpty()) ic.setComposingText("", 1)
            else ic.setComposingText(AvroPhonetic.transliterate(composing.toString()), 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    private fun pressEnter() {
        commitPending()
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun commitSpecial(value: String) {
        if (value == "?123") {
            Toast.makeText(this, "Number/symbol layout will be added in a later version.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleSpeech() {
        if (listening) {
            stopSpeech()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition service is unavailable.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Open Bangla Voice Writer Pro and grant microphone permission first.", Toast.LENGTH_LONG).show()
                return
            }
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(speechListener) }
            }
            val tag = if (mode == Mode.ENGLISH) "en-US" else "bn-BD"
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            listening = true
            refreshKeyboard()
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            listening = false
            Toast.makeText(this, "Could not start voice typing: ${e.message}", Toast.LENGTH_LONG).show()
            refreshKeyboard()
        }
    }

    private fun stopSpeech() {
        if (!listening) return
        listening = false
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        refreshKeyboard()
    }

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onResults(results: Bundle?) {
            val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                commitPending()
                val output = if (mode == Mode.ANSI) BijoyConverter.toBijoy(spoken) else spoken
                currentInputConnection?.commitText(output, 1)
            }
            listening = false
            refreshKeyboard()
        }
        override fun onError(error: Int) {
            listening = false
            Toast.makeText(this@BanglaInputMethodService, "Voice typing error ($error).", Toast.LENGTH_SHORT).show()
            refreshKeyboard()
        }
    }
}
