package com.banglavoicewriter.pro.convert

import com.banglavoicewriter.pro.convert.BijoyTables.HASANTA

/**
 * Bijoy Classic / SutonnyMJ ANSI -> Unicode Bangla (inverse of [BijoyConverter]).
 *
 * Use it on text that was typed with a Bijoy layout (or copied from a legacy
 * document). It must only be given Bijoy text: genuine English words in the
 * input would be read as Bijoy glyphs. Glyphs that are not in
 * [BijoyTables] are passed through unchanged.
 */
object BijoyToUnicode {
    private class Glyph(val type: Char, val uni: String)

    // type: C consonant/conjunct, O other, P post-kar, R pre-kar, F reph, Y ya-phala, A ra-phala, H hasanta
    private val glyphs: Map<String, Glyph> = buildMap {
        for ((u, g) in BijoyTables.consonants) put(g, Glyph('C', u))
        for ((u, g) in BijoyTables.others) put(g, Glyph('O', u))
        put("|", Glyph('O', "\u0964"))
        for ((u, g) in BijoyTables.ligatures) put(g, Glyph('C', u))
        for ((u, g) in BijoyTables.postKars) put(g, Glyph('P', u))
        put("\u0160", Glyph('P', "\u09CC#")) // second half of ou-kar
        for ((u, g) in BijoyTables.preKars) put(g, Glyph('R', u))
        put(BijoyTables.REPH, Glyph('F', ""))
        put(BijoyTables.YA_PHALA, Glyph('Y', ""))
        for (g in BijoyTables.raPhala.values.toSet()) put(g, Glyph('A', ""))
        put(BijoyTables.HASANTA_GLYPH, Glyph('H', ""))
    }
    private val maxLen: Int = glyphs.keys.maxOf { it.length }

    private class Cluster(val pre: String, var text: String) {
        var ref = false
        var post = ""
    }

    private class Tok(val type: Char, val uni: String)

    fun convert(input: String): String {
        val units = ArrayList<Tok>()
        var i = 0
        while (i < input.length) {
            var found = false
            var len = minOf(maxLen, input.length - i)
            while (len >= 1) {
                val g = glyphs[input.substring(i, i + len)]
                if (g != null) {
                    units.add(Tok(g.type, g.uni))
                    i += len
                    found = true
                    break
                }
                len--
            }
            if (!found) {
                units.add(Tok('X', input[i].toString()))
                i++
            }
        }

        val out = StringBuilder()
        var cl: Cluster? = null
        var pend = ""
        var join = false

        fun flush() {
            val c = cl ?: return
            var k = c.pre
            var post = c.post
            val kars = StringBuilder()
            if (k.contains('\u09C7') && post.contains('\u09BE')) {
                kars.append('\u09CB')
                post = post.replaceFirst("\u09BE", "")
                k = k.replaceFirst("\u09C7", "")
            } else if (k.contains('\u09C7') && post.contains("\u09CC#")) {
                kars.append('\u09CC')
                post = post.replaceFirst("\u09CC#", "")
                k = k.replaceFirst("\u09C7", "")
            }
            kars.append(k).append(post)
            if (c.ref) out.append('\u09B0').append(HASANTA)
            out.append(c.text).append(kars)
            cl = null
        }

        for (u in units) {
            val c = cl
            when {
                u.type == 'R' -> {
                    flush()
                    pend += u.uni
                }
                u.type == 'C' -> {
                    if (join && c != null) {
                        c.text += HASANTA + u.uni
                        join = false
                    } else {
                        flush()
                        cl = Cluster(pend, u.uni)
                        pend = ""
                    }
                }
                u.type == 'Y' && c != null -> {
                    c.text += (if (c.text.endsWith("\u09B0")) "\u200D" else "") + HASANTA + "\u09AF"
                }
                u.type == 'A' && c != null -> c.text += HASANTA + "\u09B0"
                u.type == 'F' && c != null -> c.ref = true
                u.type == 'P' && c != null -> c.post += u.uni
                u.type == 'H' && c != null -> join = true
                else -> {
                    flush()
                    if (pend.isNotEmpty()) {
                        out.append(pend)
                        pend = ""
                    }
                    join = false
                    out.append(u.uni)
                }
            }
        }
        flush()
        if (pend.isNotEmpty()) out.append(pend)
        return out.toString()
    }
}
