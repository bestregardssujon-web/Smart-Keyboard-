package com.banglavoicewriter.pro

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0B6E4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBDD),
    onPrimaryContainer = Color(0xFF00281A),
    secondary = Color(0xFF3F6B5B),
    tertiary = Color(0xFFB3261E),
    background = Color(0xFFF7FBF8),
    surface = Color(0xFFF7FBF8),
    surfaceVariant = Color(0xFFE0EBE4)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7DD6AF),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF00513D),
    onPrimaryContainer = Color(0xFFCDEBDD),
    secondary = Color(0xFFA6CFBD),
    tertiary = Color(0xFFFFB4AB),
    background = Color(0xFF101412),
    surface = Color(0xFF101412),
    surfaceVariant = Color(0xFF2C3530)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
