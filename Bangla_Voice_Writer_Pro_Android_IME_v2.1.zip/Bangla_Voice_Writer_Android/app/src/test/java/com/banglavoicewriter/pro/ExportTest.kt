package com.banglavoicewriter.pro

import com.banglavoicewriter.pro.editor.TextInsert
import com.banglavoicewriter.pro.export.DocxWriter
import com.banglavoicewriter.pro.export.Exporters
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExportTest {
    private fun unzip(bytes: ByteArray): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                map[e.name] = String(z.readBytes(), Charsets.UTF_8)
                e = z.nextEntry
            }
        }
        return map
    }

    private fun assertWellFormed(xml: String) {
        DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
    }

    @Test fun docxUnicodeHasRequiredPartsAndIsWellFormed() {
        val parts = unzip(DocxWriter.build("\u0986\u09AE\u09BF \u09AC\u09BE\u0982\u09B2\u09BE\n\nSecond & <line>", false))
        assertTrue(parts.containsKey("[Content_Types].xml"))
        assertTrue(parts.containsKey("_rels/.rels"))
        assertTrue(parts.containsKey("word/document.xml"))
        parts.values.forEach { assertWellFormed(it) }
        val doc = parts["word/document.xml"]!!
        assertTrue(doc.contains("\u0986\u09AE\u09BF"))
        assertTrue(doc.contains("Second &amp; &lt;line&gt;"))
        assertTrue(doc.contains("Nirmala UI"))
    }

    @Test fun docxSutonnyUsesFontOnlyForBanglaRuns() {
        val doc = unzip(DocxWriter.build("\u0986\u09AE\u09BF Hello", true))["word/document.xml"]!!
        assertWellFormed(doc)
        assertTrue(doc.contains("w:ascii=\"SutonnyMJ\""))
        assertTrue(doc.contains("Avwg"))
        assertTrue(doc.contains("w:ascii=\"Calibri\""))
        assertTrue(doc.contains(">Hello<"))
    }

    @Test fun txtUnicodeHasBomAndUtf8() {
        val b = Exporters.txtBytes("\u0986\u09AE\u09BF", false)
        assertEquals(0xEF.toByte(), b[0])
        assertEquals("\u0986\u09AE\u09BF", String(b, 3, b.size - 3, Charsets.UTF_8))
    }

    @Test fun txtSutonnyIsSingleByteWindows1252() {
        val b = Exporters.txtBytes("\u09B6\u09BF\u0995\u09CD\u09B7\u09BE", true) // shikkha -> wk(pilcrow)v
        assertEquals(4, b.size)
        assertEquals("wk\u00B6v", String(b, charset("windows-1252")))
    }

    @Test fun spokenTextInsertionSpacing() {
        assertEquals("\u0986\u09AE\u09BF", TextInsert.spoken("", 0, 0, " \u0986\u09AE\u09BF ").text)
        assertEquals("abc def", TextInsert.spoken("abc", 3, 3, "def").text)
        assertEquals("abc.", TextInsert.spoken("abc", 3, 3, ".").text)
        val r = TextInsert.spoken("one three", 4, 4, "two")
        assertEquals("one two three", r.text)
        assertEquals(7, r.cursor)
        assertEquals("X", TextInsert.exact("abc", 0, 3, "X").text)
    }
}
